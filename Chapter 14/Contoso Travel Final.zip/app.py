import os, base64, json, requests
from flask import Flask, render_template, request, flash
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import ComputerVisionErrorResponseException
from msrest.authentication import CognitiveServicesCredentials


# Define Cognitive Services variables
vision_key = 'VISION_KEY'
vision_endpoint = 'VISION_ENDPOINT'
translator_key = 'TRANSLATOR_KEY'
translator_endpoint = 'TRANSLATOR_ENDPOINT'
translator_region = 'TRANSLATOR_REGION'

app = Flask(__name__)
app.secret_key = os.urandom(24)

@app.route("/", methods=["GET", "POST"])
def index():
    language="en"

    if request.method == "POST":
        language = request.form["language"]

        # Display the image that was uploaded
        image = request.files["file"]
        uri = "data:;base64," + base64.b64encode(image.read()).decode("utf-8")
        image.seek(0)

        # Use the Computer Vision service to extract text from the image
        lines = extract_text(vision_endpoint, vision_key, image)

        # Use the Translator service to translate text extracted from the image
        translated_lines = translate_text(translator_endpoint, translator_region,
                                          translator_key, lines, language)
        
        # Flash the translated text
        for translated_line in translated_lines:
            flash(translated_line)

    else:
        # Display a placeholder image
        uri = "/static/placeholder.png"

    return render_template("index.html", image_uri=uri, language=language)

# Function that extracts text from images
def extract_text(endpoint, key, image):
    try:
        client = ComputerVisionClient(endpoint, CognitiveServicesCredentials(key))
        result = client.recognize_printed_text_in_stream(image)
        lines = []

        for region in result.regions:
            for line in region.lines:
                text = ' '.join([word.text for word in line.words])
                lines.append(text)

        if len(lines) == 0:
            lines.append('Photo contains no text to translate')

        return lines

    except ComputerVisionErrorResponseException as e:
        return ['Error calling the Computer Vision service: ' + e.message]

    except Exception as e:
        return ['Error calling the Computer Vision service']

# Function that translates text into a specified language
def translate_text(endpoint, region, key, lines, language):
    try:
        headers = {
            'Ocp-Apim-Subscription-Key': key,
            'Ocp-Apim-Subscription-Region': region,
            'Content-type': 'application/json'
        }

        input = []

        for line in lines:
            input.append({ "text": line })

        uri = endpoint + 'translate?api-version=3.0&to=' + language
        response = requests.post(uri, headers=headers, json=input)
        response.raise_for_status() # Raise exception if call failed
        results = response.json()

        translated_lines = []

        for result in results:
            for translated_line in result["translations"]:
                translated_lines.append(translated_line["text"])

        return translated_lines

    except requests.exceptions.HTTPError as e:
        return ['Error calling the Translator service: ' + e.strerror]

    except Exception as e:
        return ['Error calling the Translator service']